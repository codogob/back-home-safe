import{s as e,l,R as t}from"./vendor.edeed207.js";const a=()=>{const{t:e}=l();return t.createElement(n,null,t.createElement("p",null,e("global:disclaimer.1")),t.createElement("p",null,e("global:disclaimer.2")),t.createElement("p",null,e("global:disclaimer.3")))},n=e.div`
  width: 100%;
  text-align: center;

  & p {
    padding: 0 16px;
    font-size: 12px;
  }
`;export{a as D};
