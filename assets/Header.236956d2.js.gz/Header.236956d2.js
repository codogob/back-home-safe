import{s as e,R as t,L as a}from"./vendor.edeed207.js";const o=({name:e,backPath:o})=>t.createElement(r,null,o&&t.createElement(a,{to:o},t.createElement(s,{src:"assets/back.2d372998.svg"})),e),s=e.img`
  height: 20px;
  top: 14px;
  left: 16px;
  position: absolute;
`,r=e.div`
  color: #ffffff;
  background-color: #12b188;
  text-align: center;
  line-height: 48px;
  text-shadow: 0px 1px 2px rgba(0, 0, 0, 0.8);
  flex-shrink: 0;
`;export{o as H};
