import{l as e,R as a,s as t}from"./vendor.edeed207.js";import{D as r}from"./Disclaimer.0a45b3aa.js";import{H as n}from"./Header.236956d2.js";const s=()=>{const{t:t}=e("disclaimer");return a.createElement(l,null,a.createElement(n,{backPath:"/",name:t("name")}),a.createElement("h3",null,t("message.you_accepted")),a.createElement(r,null))},l=t.div`
  width: 100%;
  text-align: center;
  background-color: #fff;
  height: 100%;

  & p {
    padding: 0 16px;
    font-size: 12px;
  }
`;export{s as default};
